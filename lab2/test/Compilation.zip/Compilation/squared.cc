// Implementation file for squared module

#include "squared.h"




int squared (int number) {
   return (number*number);
}

