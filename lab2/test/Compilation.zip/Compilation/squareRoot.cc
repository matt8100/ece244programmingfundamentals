// Implementation file of the squareRoot module

#include <cmath>

#include "squareRoot.h"

float squareRoot (int number) {
   return (sqrt(number));
}

