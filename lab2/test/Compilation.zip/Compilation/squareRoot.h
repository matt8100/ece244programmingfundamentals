#ifndef _squareRoot_h
#define _squareRoot_h
// Definition file for squareRoot module

float squareRoot(int);

#endif


