#ifndef _squared_h
#define _squared_h

// Definition file for squared module
int squared (int);

#endif

